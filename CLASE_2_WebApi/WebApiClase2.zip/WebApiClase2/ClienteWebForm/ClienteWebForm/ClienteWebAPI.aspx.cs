﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ClienteWebForm
{
    public partial class ClienteWebAPI:System.Web.UI.Page
    {
        protected void Page_Load(object sender,EventArgs e)
        {
            if(!Page.IsPostBack)
            {
                VerAmigos(0);
            }
        }
        void VerAmigos(int id)
        {
            var t = Task.Run(() => GetURI(new Uri("https://localhost:44373/api/amigos")));
            t.Wait();
            JArray j = JArray.Parse(t.Result);
            List<Amigo> friends = JsonConvert.DeserializeObject<List<Amigo>>(t.Result.ToString());
            if(id != 0)
            {
                friends = (from f in friends
                           where f.ID == id
                           select f).ToList();
            }


            gvAmigos.DataSource = friends;
            gvAmigos.DataBind();

        }

        static async Task<string> GetURI(Uri u)
        {
            var response = string.Empty;
            using(var client = new HttpClient())
            {
                HttpResponseMessage result = await client.GetAsync(u);
                if(result.IsSuccessStatusCode)
                {
                    response = await result.Content.ReadAsStringAsync();
                }
            }
            return response;
        }

        protected void btnBuscar_Click(object sender,EventArgs e)
        {
            int intID = Convert.ToInt32(txtID.Text);
            VerAmigos(intID);
        }
    }
}