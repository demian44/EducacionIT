﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIClase2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace APIClase2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AmigosController : ControllerBase
    {
        private readonly ApplicationDBContext db;
        // aplicamos inyeccion de dependencia para app dbContext
        // en el constructor
        public AmigosController(ApplicationDBContext contexto)
        {
            this.db = contexto;
        }
        public List<Models.Amigo> GetAll()
        {
            var amigos = from a in db.Amigos
                         select a;
            return amigos.ToList();
        }
        [HttpGet("{id}")]
        public ActionResult GetByID(int? id)
        {
            var amigo = db.Amigos.Find(id);
            if(amigo == null)
            {
                return NotFound();
            }
            return Ok(amigo);
        }
    }
}